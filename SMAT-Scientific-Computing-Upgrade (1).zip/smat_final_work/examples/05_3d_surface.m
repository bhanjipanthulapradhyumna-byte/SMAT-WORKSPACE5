% 3D surface plotting
[x,y] = meshgrid(linspace(-5,5,100));
r = sqrt(x.^2 + y.^2) + eps;
z = sin(r)./r;
figure;
surf(x,y,z);
shading interp; colorbar; xlabel('x'); ylabel('y'); zlabel('z');
title('3D sinc surface');
