% Arithmetic, variables, output, clear/clc/who/whos
clc; clear;
a = 12; b = 5;
sum_value = a + b;
product_value = a * b;
remainder_value = mod(a,b);
fprintf('sum = %g\nproduct = %g\nremainder = %g\n', sum_value, product_value, remainder_value);
who
whos
