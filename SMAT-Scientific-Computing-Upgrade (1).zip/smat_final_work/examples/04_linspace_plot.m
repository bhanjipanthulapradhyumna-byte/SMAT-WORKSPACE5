% linspace and plotting
x = linspace(0, 2*pi, 500);
y1 = sin(x);
y2 = cos(x);
figure;
plot(x,y1,'b-','LineWidth',2);
hold on;
plot(x,y2,'r--','LineWidth',2);
grid on;
title('Sine and cosine'); xlabel('x (radians)'); ylabel('amplitude');
legend('sin(x)','cos(x)');
