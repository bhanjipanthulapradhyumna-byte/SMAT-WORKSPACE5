% Arrays, matrix arithmetic and element-wise arithmetic
A = [1 2 3; 4 5 6; 7 8 10];
B = eye(3);
C = A + B;
D = A * B;
E = A .* (B + 2);
disp('A + I ='); disp(C);
disp('A * I ='); disp(D);
disp('Element-wise result ='); disp(E);
disp('det(A) ='); disp(det(A));
