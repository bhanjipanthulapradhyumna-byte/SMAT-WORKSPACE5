# SMAT MATLAB-style examples
Run each `.m` file in SMAT using GNU Octave. The examples exercise arithmetic, arrays and matrices, element-wise operations, `linspace`, `clc`, `clear`, `who`, `whos`, loops, decisions, logical operators, formatted output and 2D/3D plots.

`input()` is supported by Octave, but in a non-interactive HTTP execution the prompt may not be connected to a live terminal. For web forms, pass values as script variables or build a UI input form. Desktop GUI calls such as `uicontrol`, `figure` interactions and App Designer are not equivalent to a browser GUI. Simulink itself is proprietary; this package does not include MathWorks Simulink. A browser-based block-diagram simulator would need to be implemented separately.
