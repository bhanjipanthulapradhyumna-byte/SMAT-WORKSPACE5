% for, while, if/elseif/else, logical operators
total = 0;
for k = 1:10
    if mod(k,2) == 0 && k > 4
        total = total + k;
    elseif mod(k,2) ~= 0
        total = total + 1;
    end
end
fprintf('total = %g\n', total);
n = 1;
while n < 5
    fprintf('n = %d\n', n);
    n = n + 1;
end
