@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is missing. Install it from https://nodejs.org/ & pause & exit /b 1)
where octave >nul 2>nul || (echo GNU Octave is missing or not on PATH. Install it from https://octave.org/download/ & pause & exit /b 1)
set HOST=127.0.0.1
if not defined PORT set PORT=8080
node server.js
pause
