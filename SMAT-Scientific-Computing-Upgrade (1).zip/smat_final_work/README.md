# SMAT — MATLAB-style scientific computing studio

SMAT uses GNU Octave as its execution engine. Octave is a free scientific computing language with syntax largely compatible with MATLAB and built-in 2D/3D plotting. Compatibility is broad, not complete.

## Features via GNU Octave
- Arithmetic, comparison and logical operators
- Matrix/array creation, indexing, matrix multiplication and element-wise operators (`.*`, `./`, `.^`)
- Colon ranges and `linspace`
- `clc`, `clear`, `who`, `whos`
- `if`/`elseif`/`else`, `switch`, `for`, `while`, `break`, `continue`
- `disp`, `fprintf`, `input` where interactive input is available
- 2D/3D plotting commands supported by Octave, exported as a PNG after execution
- Execution timeout and output limits

See `examples/` for runnable tests.

## Run locally on Windows
1. Install Node.js 18+ and GNU Octave; ensure `octave` is available on PATH.
2. Extract this ZIP and double-click `START-SMAT-WINDOWS.bat`.
3. Open `http://127.0.0.1:8080`; keep the terminal open.

## Docker / free-tier deployment
The included `Dockerfile` installs Octave and a headless plotting toolkit. Push the project to a GitHub repository and create a Docker web service on a provider such as Render. Set `HOST=0.0.0.0`, `PORT` is supplied by the host, and configure `SMAT_API_KEY` (the included Render blueprint generates one). In the browser, use **Execution key** and enter the generated key. The key is kept in session storage for that tab.

**Free-tier caveats:** free instances may sleep, have limited RAM/CPU and build-time limits; installing Octave can make the image large. Check current provider limits before deploying.

## Security
Running arbitrary scripts is dangerous. The server has a timeout and can require an API key, but this is not a complete hostile-code sandbox. Do not offer public execution to untrusted users without stronger isolation (container-per-run, network disabled, filesystem limits, quotas, authentication, abuse monitoring). The API key is a basic gate, not a full user-account system.

## GUI and Simulink limitations
This package is a code-based MATLAB-style environment, not a full MATLAB or Simulink clone. Desktop GUI functions and App Designer do not translate automatically to a browser. Real Simulink compatibility requires a separate graphical block editor and simulation engine; this package does not claim to implement MathWorks Simulink.
